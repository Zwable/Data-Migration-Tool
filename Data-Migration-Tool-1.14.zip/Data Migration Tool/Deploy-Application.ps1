﻿<#
.SYNOPSIS
	This script performs the installation or uninstallation of an application(s).
.DESCRIPTION
	The script is provided as a template to perform an install or uninstall of an application(s).
	The script either performs an "Install" deployment type or an "Uninstall" deployment type.
	The install deployment type is broken down into 3 main sections/phases: Pre-Install, Install, and Post-Install.
	The script dot-sources the AppDeployToolkitMain.ps1 script which contains the logic and functions required to install or uninstall an application.
.PARAMETER DeploymentType
	The type of deployment to perform. Default is: Install.
.PARAMETER DeployMode
	Specifies whether the installation should be run in Interactive, Silent, or NonInteractive mode. Default is: Interactive. Options: Interactive = Shows dialogs, Silent = No dialogs, NonInteractive = Very silent, i.e. no blocking apps. NonInteractive mode is automatically set if it is detected that the process is not user interactive.
.PARAMETER AllowRebootPassThru
	Allows the 3010 return code (requires restart) to be passed back to the parent process (e.g. SCCM) if detected from an installation. If 3010 is passed back to SCCM, a reboot prompt will be triggered.
.PARAMETER TerminalServerMode
	Changes to "user install mode" and back to "user execute mode" for installing/uninstalling applications for Remote Destkop Session Hosts/Citrix servers.
.PARAMETER DisableLogging
	Disables logging to file for the script. Default is: $false.
.EXAMPLE
    powershell.exe -Command "& { & '.\Deploy-Application.ps1' -DeployMode 'Silent'; Exit $LastExitCode }"
.EXAMPLE
    powershell.exe -Command "& { & '.\Deploy-Application.ps1' -AllowRebootPassThru; Exit $LastExitCode }"
.EXAMPLE
    powershell.exe -Command "& { & '.\Deploy-Application.ps1' -DeploymentType 'Uninstall'; Exit $LastExitCode }"
.EXAMPLE
    Deploy-Application.exe -DeploymentType "Install" -DeployMode "Silent"
.NOTES
	Toolkit Exit Code Ranges:
	60000 - 68999: Reserved for built-in exit codes in Deploy-Application.ps1, Deploy-Application.exe, and AppDeployToolkitMain.ps1
	69000 - 69999: Recommended for user customized exit codes in Deploy-Application.ps1
	70000 - 79999: Recommended for user customized exit codes in AppDeployToolkitExtensions.ps1
.LINK 
	http://psappdeploytoolkit.com
#>
[CmdletBinding()]
Param (
	[Parameter(Mandatory=$false)]
	[ValidateSet('Install','Uninstall')]
	[string]$DeploymentType = 'Install',
	[Parameter(Mandatory=$false)]
	[ValidateSet('Interactive','Silent','NonInteractive')]
	[string]$DeployMode = 'Interactive',
	[Parameter(Mandatory=$false)]
	[switch]$AllowRebootPassThru = $false,
	[Parameter(Mandatory=$false)]
	[string]$BackupPath,
	[Parameter(Mandatory=$false)]
	[switch]$TerminalServerMode = $false,
	[Parameter(Mandatory=$false)]
	[string]$NetworkLocation = '\\ZWA-FILE01\UsmtBackupShare$',
	[Parameter(Mandatory=$false)]
	[switch]$BackupDomainUsersOnly = $false,
	[Parameter(Mandatory=$false)]
	[string]$BackupDomainUsersLoginWithinDays = '30', #only used if BackupDomainUsersOnly is true
	[Parameter(Mandatory=$false)]
	[switch]$DisableLogging = $false
)

Try {
	## Set the script execution policy for this process
	Try { Set-ExecutionPolicy -ExecutionPolicy 'ByPass' -Scope 'Process' -Force -ErrorAction 'Stop' } Catch {}
	
	##*===============================================
	##* VARIABLE DECLARATION
	##*===============================================
	## Variables: Application
	[string]$appVendor = 'Zwable'
	[string]$appName = 'Data Migration Tool'
	[string]$appVersion = '1.14'
	[string]$appArch = ''
	[string]$appLang = 'EN'
	[string]$appRevision = '01'
	[string]$appScriptVersion = '1.0.0'
	[string]$appScriptDate = '26-11-2019'
	[string]$appScriptAuthor = 'Morten Rønborg'
	##*===============================================
	## Variables: Install Titles (Only set here to override defaults set by the toolkit)
	[string]$installName = ''
	[string]$installTitle = ''
	
	##* Do not modify section below
	#region DoNotModify
	
	## Variables: Exit Code
	[int32]$mainExitCode = 0
	
	## Variables: Script
	[string]$deployAppScriptFriendlyName = 'Deploy Application'
	[version]$deployAppScriptVersion = [version]'3.6.9'
	[string]$deployAppScriptDate = '02/12/2017'
	[hashtable]$deployAppScriptParameters = $psBoundParameters
	
	## Variables: Environment
	If (Test-Path -LiteralPath 'variable:HostInvocation') { $InvocationInfo = $HostInvocation } Else { $InvocationInfo = $MyInvocation }
	[string]$scriptDirectory = Split-Path -Path $InvocationInfo.MyCommand.Definition -Parent
	
	## Dot source the required App Deploy Toolkit Functions
	Try {
		[string]$moduleAppDeployToolkitMain = "$scriptDirectory\AppDeployToolkit\AppDeployToolkitMain.ps1"
		If (-not (Test-Path -LiteralPath $moduleAppDeployToolkitMain -PathType 'Leaf')) { Throw "Module does not exist at the specified location [$moduleAppDeployToolkitMain]." }
		If ($DisableLogging) { . $moduleAppDeployToolkitMain -DisableLogging } Else { . $moduleAppDeployToolkitMain }
	}
	Catch {
		If ($mainExitCode -eq 0){ [int32]$mainExitCode = 60008 }
		Write-Error -Message "Module [$moduleAppDeployToolkitMain] failed to load: `n$($_.Exception.Message)`n `n$($_.InvocationInfo.PositionMessage)" -ErrorAction 'Continue'
		## Exit the script, returning the exit code to SCCM
		If (Test-Path -LiteralPath 'variable:HostInvocation') { $script:ExitCode = $mainExitCode; Exit } Else { Exit $mainExitCode }
	}
	
	#endregion
	##* Do not modify section above
	##*===============================================
	##* END VARIABLE DECLARATION
	##*===============================================
		
	If ($deploymentType -ine 'Uninstall') {
		##*===============================================
		##* PRE-INSTALLATION
		##*===============================================
		[string]$installPhase = 'Pre-Installation'
		
		
		##*===============================================
		##* INSTALLATION 
		##*===============================================
		[string]$installPhase = 'Installation'

		## Declare USMT variables
        [string]$USMTPath = $dirFiles
		[string]$Profile = $($CurrentLoggedOnUserSession.UserName)
		[string]$DomainName = $($CurrentLoggedOnUserSession.DomainName)
		[string]$SavedWLANDir = "C:\Users\$Profile\Documents\USMT-DataMigrationTool-Saved-WLANS"
		[boolean]$NetworkLocationExists = [System.IO.Directory]::Exists($NetworkLocation)

		#Check to se if there is any external media available
		If($ExternalMedia = Get-ExternalMedia){

			#Define variables
			$DriveID = $ExternalMedia[0].DeviceID
			$VolName = $ExternalMedia[0].VolumeName
			$FreeSpace = ([Math]::Round($ExternalMedia[0].FreeSpace / 1GB,1).ToString() + " GB")
			$Size = ([Math]::Round($ExternalMedia[0].Size /  1GB,1).ToString() + " GB")
			
			#Write to the log
			Write-Log "USB device detected, asking user to use that as migration point"
			
			#If network location is available, show button, else dont
			if($NetworkLocationExists){

				#Define message text
				$MessageText = "Choose migration file location:`n`nDrive ID: $DriveID`nVolume name: $VolName`nTotal size:$Size`nFree space:$FreeSpace  `n`nUsing network will default to the network location`n($NetworkLocation\$profile)"
				
				#Give the user the choice
				$LocationChoice = Show-InstallationPrompt -Message $MessageText  -ButtonLeftText 'Use USB' -ButtonMiddleText 'Use network share' -ButtonRightText 'Cancel'
			}else{
								
				#Define message text
				$MessageText = "Choose migration file location. Be sure to have enough space on the location:`n`nDrive ID: $DriveID`nVolume name: $VolName`nTotal size:$Size`nFree space:$FreeSpace"
				
				#Give the user the choice
				$LocationChoice = Show-InstallationPrompt -Message $MessageText  -ButtonLeftText 'Use USB' -ButtonRightText 'Cancel'
			}

		}else{

			#If no USB was detected, use network share
			$LocationChoice = "Use network share"
		}

		#Define the MIG location and check share
		if($LocationChoice -eq "Use network share"){
			$Location = $NetworkLocation
			Write-Log "User choose to use the network as migration device"

			#Check to see if there is network connectivity to the share
			If($NetworkLocationExists -eq $false){
				$MessageText = "No connection to the backup share. `nCheck your connectivity and try again, or connect an external storage device and run again. "
				Show-InstallationPrompt -Message $MessageText -ButtonMiddleText 'Exit'
				Exit-script
			}
		}elseif($LocationChoice -eq  'Use USB'){
			$Location =  $DriveID
			Write-Log "User choose to use the USB as migration device"
		}else{
			Write-Log "User choose to cancel"
			Exit-script
		}

		Write-Log "Currently running USMT for the user $Profile for this share $Location\$Profile"


        #Check to see if there is an backup already
        if([System.IO.File]::Exists("$Location\$Profile\USMT\USMT.MIG")){
            Write-Log "Backup detected, giving the user the option to restore.."
            $BackupInfo = Get-ChildItem "$Location\$profile\USMT\USMT.MIG"
            $BackupAge = $BackupInfo.LastWriteTime.ToString("yyyy-MM-dd HH:mm")
            $BackupGBSize =[Math]::Round((($BackupInfo | Measure-Object -Property length -sum).sum /1GB),3)
        }

        #Static text in messagebox
        $MessageText = "Welcome to the Data Migration Tool. This makes it possible to backup your data and restore to a new PC.`n`nThis tool includes backup of:`n Custom created folders in C:\, My Documents, Desktop, Dowloads etc.`n"
        
        #Define messagetext if there is a backup or not
        if($Backupinfo){
            $MessageText += "`nCurrent backup available for your userprofile:`n $BackupAge `n $BackupGBSize GB " 
            }else{

        }

        #Show the dialog box for end user and define an option
        if(!($Backupinfo)){

			#Show installation prompt
			$Choice = Show-InstallationPrompt -Message $MessageText -ButtonLeftText 'Backup' -ButtonRightText 'Cancel'
            }else{

			#Show installation prompt
			$Choice = Show-InstallationPrompt -Message $MessageText -ButtonMiddleText 'Backup' -ButtonLeftText 'Restore' -ButtonRightText 'Cancel'
        }

        #If user choose to take a backup while there is one already 
        if($Choice -eq "Backup"){

            #If there is already a backup give a prompt
            if($BackupInfo){

				#Show installation prompt with a prompt telling there is already a backup
                $ChoiceAlreadyBackup = Show-InstallationPrompt -Message "WARNING:`nThere is already a backup available.`n Continuing this will overwrite the old backup. " -ButtonLeftText 'Continue' -ButtonRightText 'Cancel'
				
				#Exit if choocen cancel
                if($ChoiceAlreadyBackup -eq "Cancel"){
                    Exit-script
                    }
				}
				
            #If the user didn't cancel then take the backup and force delete the old backup if present
			Show-InstallationProgress -StatusMessage "Performing backup. This may take a while.." -WindowLocation BottomRight -TopMost $True
			
			#Export WLAN profiles to the desired destination if running on a physical machine
			if((Get-HardwarePlatform) -eq "Physical"){

				#Export the profiles
				Write-Log "Running on a physical machine, exporting available WLAN profiles to '$SavedWLANDir'.."
				Export-WLANProfiles -Path $SavedWLANDir
			}else{

				#Running on a virtual machine, skipping WLAN export
				Write-Log "Running on a virtual machine, skipping WLAN export.."
			}

			#Perform the backup
            if($BackupDomainUsersOnly){
                Start-UserStateMigrationTool -USMTPath $USMTPath -DestinationPath $Location -Profile $profile -UserScope "/ui:$DomainName\* /uel:$BackupDomainUsersLoginWithinDays" -Force
            }else{
                Start-UserStateMigrationTool -USMTPath $USMTPath -DestinationPath $Location -Profile $profile -Force
            }

			#Tell the user if it succeded or not
			if([System.IO.File]::Exists("$Location\$Profile\USMT\USMT.MIG")){
            	Show-InstallationPrompt -Message "Backup complete.`n`nRun the tool on the destination computer to perform the restore." -ButtonMiddleText 'Exit' -NoWait
			}else{
				Show-InstallationPrompt -Message "Backup failed. This could be caused by encrypted files on your documents or desktop folder. Read more here: `n`n $Location\$Profile\" -ButtonMiddleText 'Exit' -NoWait -icon Error				
			}

		}
        
        #Perform restore if choosen
         if($Choice -eq "Restore"){
            Show-InstallationProgress -StatusMessage "Performing restore. This may take a while.." -WindowLocation BottomRight -TopMost $True
			Start-UserStateMigrationTool -USMTPath $USMTPath -DestinationPath $Location -Profile $Profile -NoAppSettings -Restore 
			Import-WLANProfiles -Path $SavedWLANDir -Cleanup
            Show-InstallationPrompt -Message "Restore complete" -ButtonMiddleText 'Exit' -NoWait   
         }

		##*===============================================
		##* POST-INSTALLATION
		##*===============================================
		[string]$installPhase = 'Post-Installation'
		
		## <Perform Post-Installation tasks here>
		
		## Display a message at the end of the install
		#If (-not $useDefaultMsi) { Show-InstallationPrompt -Message 'You can customize text to appear at the end of an install or remove it completely for unattended installations.' -ButtonRightText 'OK' -Icon Information -NoWait }
	}
	ElseIf ($deploymentType -ieq 'Uninstall')
	{
		##*===============================================
		##* PRE-UNINSTALLATION
		##*===============================================
		[string]$installPhase = 'Pre-Uninstallation'
		
		##*===============================================
		##* UNINSTALLATION
		##*===============================================
		[string]$installPhase = 'Uninstallation'
		
		
		
		##*===============================================
		##* POST-UNINSTALLATION
		##*===============================================
		[string]$installPhase = 'Post-Uninstallation'
		
		## <Perform Post-Uninstallation tasks here>
		
		
	}
	
	##*===============================================
	##* END SCRIPT BODY
	##*===============================================
	
	## Call the Exit-Script function to perform final cleanup operations
	Exit-Script -ExitCode $mainExitCode
}
Catch {
	[int32]$mainExitCode = 60001
	[string]$mainErrorMessage = "$(Resolve-Error)"
	Write-Log -Message $mainErrorMessage -Severity 3 -Source $deployAppScriptFriendlyName
	Show-DialogBox -Text $mainErrorMessage -Icon 'Stop'
	Exit-Script -ExitCode $mainExitCode
}