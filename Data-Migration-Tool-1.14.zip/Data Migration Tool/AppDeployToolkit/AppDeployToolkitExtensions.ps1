﻿<#
.SYNOPSIS
	This script is a template that allows you to extend the toolkit with your own custom functions.
.DESCRIPTION
	The script is automatically dot-sourced by the AppDeployToolkitMain.ps1 script.
.NOTES
    Toolkit Exit Code Ranges:
    60000 - 68999: Reserved for built-in exit codes in Deploy-Application.ps1, Deploy-Application.exe, and AppDeployToolkitMain.ps1
    69000 - 69999: Recommended for user customized exit codes in Deploy-Application.ps1
    70000 - 79999: Recommended for user customized exit codes in AppDeployToolkitExtensions.ps1
.LINK 
	http://psappdeploytoolkit.com
#>
[CmdletBinding()]
Param (
)

##*===============================================
##* VARIABLE DECLARATION
##*===============================================

# Variables: Script
[string]$appDeployToolkitExtName = 'PSAppDeployToolkitExt'
[string]$appDeployExtScriptFriendlyName = 'App Deploy Toolkit Extensions'
[version]$appDeployExtScriptVersion = [version]'1.5.0'
[string]$appDeployExtScriptDate = '02/12/2017'
[hashtable]$appDeployExtScriptParameters = $PSBoundParameters

##*===============================================
##* FUNCTION LISTINGS
##*===============================================

# <Your custom functions go here>
Function Start-UserStateMigrationTool{
    param(
        [parameter(Mandatory=$false)][switch]$Restore,
        [parameter(Mandatory=$true)][string]$DestinationPath,
        [parameter(Mandatory=$true)][string]$USMTPath,
        [parameter(Mandatory=$false)][string]$UserScope = "ALL",
        [parameter(Mandatory=$false)][string]$Profile = $ENV:COMPUTERNAME,
        [parameter(Mandatory=$false)][int]$LogLevel = "4",
        [parameter(Mandatory=$false)][switch]$Force = $false,
        [parameter(Mandatory=$false)][switch]$NoAppSettings
    )
    <#
    .SYNOPSIS
    This function migraties data using USMT 
    .LINK
    https://www.mroenborg.com
    #>

    ####Variables
    if($NoAppSettings){
        $MigrationXML = "/i:`"$USMTPath\MigDocs.xml`" /i:`"$USMTPath\MigUser.xml`"" 
    }else { 
        $MigrationXML = "/i:`"$USMTPath\MigDocs.xml`" /i:`"$USMTPath\MigUser.xml`" /i:`"$USMTPath\MigApp.xml`"" 
    }
    #Set migration scope
	if($UserScope -ne "ALL"){
        $MigScope = "$UserScope"
    }else{
        $MigScope = "/all"
    }
    ####Variables end

    #Test to see if the path is present
    if(!($USMTPath)){
        Write-Log "The USMT files folder is not present at the specified location: '$($USMTPath)'. Stopping..."
        Return
    }

    #If restore is not defined, do a backup
    if(!($Restore)){

        #Backup 
        Write-Log "Performing backup to '$($DestinationPath)'"

        #Checking if the folder is present
        if(!(Test-Path $DestinationPath\$Profile)){
            
            #No profile currently exists for $profile.
            Write-Log "Folder for backup was not present, creating it: '$DestinationPath\$Profile'."
            New-Item $DestinationPath\$Profile -Type Directory | Out-Null
        }elseif((Test-Path $DestinationPath\$Profile) -and ($Force)){

            # Profile exists but -force is specified. Clean profile.
            Write-Log "Existing path '$DestinationPath\$Profile' will be deleted due to -force parameter."
            Remove-Item $Location\$profile -Recurse -Force | Out-Null
            New-Item $Location\$profile -Type Directory | Out-Null
        }else{

            # Profile exists and -force is not specified. Return 
            Write-Log "Existing path '$DestinationPath\$Profile' and the -force parameter was not specified. Stopping..."
            Return
        }

        #Execute the process /uel:0 = logged on user, use that insted of /all
	    Execute-Process -Path "$USMTPath\SCANSTATE.EXE" -Parameters "`"$DestinationPath\$Profile`" /c /vsc $migrationXML /l:`"$DestinationPath\$Profile\SAVESTATE.log`" $migScope /localonly /v:$loglevel /progress:`"$DestinationPath\$Profile\PROGRESS.log`"" -WindowStyle Hidden -IgnoreExitCodes "3"

    }else{

        #Checking if the backup file is present
        if(!(Test-Path "$DestinationPath\$Profile")){
            Write-Log "No backup files found on the specified location'$DestinationPath\$Profile'. You must specify the location from the previous capture." 
            Return
        }

        #Execute the process
	    Execute-Process -Path "$USMTPath\LOADSTATE.EXE" -Parameters "`"$DestinationPath\$Profile`" $migrationXML /l:`"$DestinationPath\$Profile\LOADSTATE.log`" /v:$loglevel /progress:`"$DestinationPath\$Profile\PROGRESS.log`" /c" -WindowStyle Hidden -IgnoreExitCodes "3"
	
    }
}
Function Export-WLANProfiles{
    param(
        [parameter(Mandatory=$true)][string]$Path
    )
    <#
    .SYNOPSIS
    Exports WLAN profiles to a specific folder
    .LINK
    https://www.mroenborg.com
    #>

    #Get the current WLAN profiles for all users using netsh
    $WLANProfiles = netsh.exe wlan show profiles | Select-String -Pattern "All User Profile"

    #Sort the string data, put into array and remove empty lines
    $WLANProfiles = ($WLANProfiles -split "    All User Profile     : ") |  Where-Object {$_ -ne ""}

    #Check to see if the path is present
    If(!(Test-Path -Path $Path)){

        #Path not present, creating it
        New-Item -Path $Path -Force -ItemType Directory | Out-Null
    }

    #Export the WLAN profiles to the desired destination
    $WLANProfiles | ForEach-Object {
        netsh.exe wlan export profile $_ $Path key=clear | Out-Null
    }
    
}

Function Import-WLANProfiles {
    param(
        [parameter(Mandatory=$true)][string]$Path,
        [parameter(Mandatory=$False)][switch]$Cleanup
    )
    <#
    .SYNOPSIS
    Imports WLAN profiles from a specific folder
    .LINK
    https://www.mroenborg.com
    #>

    #Get folder files
    $WLANProfiles = Get-ChildItem -Path $Path -ErrorAction SilentlyContinue

    #Check to se if the folder consists of other files than XML files
    If($WLANProfiles | Foreach-Object {If($_.Name -notmatch ".xml"){Return $True}}){
        
        #Switch the cleanup switch off
        $Cleanup = $False
    }

    #Import the Wlan profiles
    $WLANProfiles | ForEach-Object {

        #Import the profiles
        netsh.exe wlan add profile filename=($Path+"\"+$_.Name) | Out-Null
    }

    #Delete the folder
    If($Cleanup){

        #Delete the folder
        Remove-Item -Path $Path -Force -Recurse -ErrorAction SilentlyContinue | Out-Null
    }
}
Function Get-ExternalMedia {
    <#
    .SYNOPSIS
    This returns an  array of external media
    .LINK
    https://www.mroenborg.com
    #>

    #Define the array
    $ExternalMedia = (gwmi win32_diskdrive | Where-Object{($_.MediaType -eq "External hard disk media") -or ($_.InterFacetype -eq "USB")} |`
    %{gwmi -Query "ASSOCIATORS OF {Win32_DiskDrive.DeviceID=`"$($_.DeviceID.Replace('\','\\'))`"} WHERE AssocClass = Win32_DiskDriveToDiskPartition"} |`
    %{gwmi -Query "ASSOCIATORS OF {Win32_DiskPartition.DeviceID=`"$($_.DeviceID)`"} WHERE AssocClass = Win32_LogicalDiskToPartition"})


    #Convert from ManagementBaseObject to array
    $MediaArray = @()
    $MediaArray += $ExternalMedia

    Return ,$MediaArray
}

##*===============================================
##* END FUNCTION LISTINGS
##*===============================================

##*===============================================
##* SCRIPT BODY
##*===============================================

If ($scriptParentPath) {
	Write-Log -Message "Script [$($MyInvocation.MyCommand.Definition)] dot-source invoked by [$(((Get-Variable -Name MyInvocation).Value).ScriptName)]" -Source $appDeployToolkitExtName
}
Else {
	Write-Log -Message "Script [$($MyInvocation.MyCommand.Definition)] invoked directly" -Source $appDeployToolkitExtName
}

##*===============================================
##* END SCRIPT BODY
##*===============================================