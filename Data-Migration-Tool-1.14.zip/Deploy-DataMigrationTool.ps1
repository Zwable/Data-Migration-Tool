<#
.SYNOPSIS
	This script deploys the Data Migration Tool
.DESCRIPTION
    Deploys 
.NOTES
    File Name  : Deploy-DataMigrationTool.ps1
    Author     : Morten Rønborg
   Requires    : PowerShell Version 4
#>

param(
    [switch]$Uninstall,
    [string]$InstallLocation = "$env:ProgramFiles\Data Migration Tool",
    [string]$LogFolder = "C:\Windows\Logs\Software"
)

#Define variables
if (!($Uninstall)){
$Log = $LogFolder + "\Data_Migration_Install_" + (Get-Date -UFormat "%d-%m-%Y") + ".log"
}else{
$Log = $LogFolder + "\Data_Migration_Uninstall_" + (Get-Date -UFormat "%d-%m-%Y") + ".log"
}

#Create path if not there
New-Item -ItemType Directory -Force -Path $LogFolder

# Write log function
Function Write-Log
{
	param ([array]$logOutput,
		[string]$Path = $Log
	)
	$currentDate = (Get-Date -UFormat "%d-%m-%Y")
	$currentTime = (Get-Date -UFormat "%T")
	$logOutput = $logOutput -join (" ")
	"[$currentDate $currentTime] $logOutput" | Out-File $Path -Append
}

#Make the installation
If (!($Uninstall)){
        try {

            #Copy the files to the dir
            robocopy.exe "`"$PSScriptRoot\Data Migration Tool"`" "`"$InstallLocation`"" /LOG+:$log /MIR
        }
        catch {
            
            #Error, write to the log
            Write-log "$_"    
        }

        try {

            #Crete the shortcut the app is present
            if (test-path -path "$InstallLocation\Deploy-Application.exe") {
                $WshShell = New-Object -comObject WScript.Shell
                $Shortcut = $WshShell.CreateShortcut("C:\ProgramData\Microsoft\Windows\Start Menu\Programs\Data Migration Tool.lnk")
                $Shortcut.TargetPath = "$InstallLocation\Deploy-Application.exe"
                $Shortcut.IconLocation = "$InstallLocation\AppDeployToolkit\AppDeployToolkitLogo.ico"
                $Shortcut.Save()
                Write-log "Shortcut created.."
            }
        } Catch {

            #Error, write to the log
            Write-log "Failed to create shortcut.... $_"
        }
    
 
} else {
        try {

            #Remove the directory and shortcuts
            Remove-Item -Path "C:\ProgramData\Microsoft\Windows\Start Menu\Programs\Data Migration Tool.lnk" -force -Recurse
            Remove-Item -Path "$InstallLocation\" -force -Recurse
            Write-log "Deleted folder and shortcut"
        }
        catch {

            #Error, write to the log
            Write-log "Failed delete folder and shortcut... $_"
        }

}

